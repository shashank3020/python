
from processor.load_processor import LoadProcessFactory
from confluent_kafka import Consumer, KafkaError

"""
    event will aws lamdab's input json structure i.e
    {
        "input": {
            "bootstrap.servers":"localhost:5657",
            "group.id": "abscd"
            "auto.offset.reset": "",
            "topic": "topic-a"
        },
        "output":{
            "module":"kafkap|dynamodb|restapi",
            "module_config":{
            "bootstrap.servers": "kafka-broker-url:9092",
            "client.id": "my-producer",
            "topic":"topic-b"
            }
        }
    }

    """


def lambda_handler(event, context):
    process_factory = LoadProcessFactory()

    # Initialize Kafka consumer
    consumer = Consumer({
        "bootstrap.servers": event["input"]["bootstrap_servers"],
        "group.id": event["input"]["group_id"],
        "auto.offset.reset": event["input"]["auto.offset.reset"]
    })

    # Subscribe
    consumer.subscribe([event["input"]["topic"]])

    # This line will return instance of processor based on configuration
    # which can be kafka, dynamodb or restapi drivers
    processData = process_factory.create_process_driver(
        event["output"]["module"], event["output"]["module_config"])

    # It create instance of module server
    processData.init()

    # Consuming kafaka topic which defined in the config
    while True:
        message = consumer.poll(1.0)
        if message is None:
            continue
        if message.error():
            if message.error().code() == KafkaError._PARTITION_EOF:
                print(
                    f"Reached end of partition:\
                        {message.topic()}:{message.partition()}")
            else:
                print(f"Error while consuming message: {message.error()}")
        else:
            processData.process_data(message)

    processData.shutdown()
    consumer.close()
