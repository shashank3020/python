import abc


class ProcessDataInterface(metaclass=abc.ABCMeta):
    @abc.abstractmethod
    def init(self):
        pass

    @abc.abstractmethod
    def process_data(self):
        pass

    @abc.abstractmethod
    def shutdown(self):
        pass
