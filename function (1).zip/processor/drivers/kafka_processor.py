
from .interfaces.process_data_interface import ProcessDataInterface
from confluent_kafka import Producer


class KafkaProducer(ProcessDataInterface):
    configuration = None
    producer = None

    def __init__(self, configuration):
        self.configuration = {
            "bootstrap.servers": configuration["kafka-broker-url:9092"],
            "client.id": configuration["client_id"]
        }
        self.topic = configuration["topic"]

    def applyOrModifyData(self, data):
        return data

    def delivery_report(self, err, msg):
        if err is not None:
            print(f"Message delivery failed: {err}")
        else:
            print(f"Message delivered to {msg.topic()} [{msg.partition()}]")

    def init(self):
        print('init')
        self.producer = Producer(self.configuration)

    def process_data(self, data):
        print('process_data')
        if not isinstance(self.producer, Producer):
            raise Exception(
                "Procedure is not intiated. Call `init` \
                    before calling the function")

        modified_data = self.applyOrModifyData(data)

        self.producer.produce(
            self.topic, key=None, value=modified_data,
            callback=self.delivery_report)

    def shutdown(self):
        print('shutdown')
        # self.kafkaProducer.close()
