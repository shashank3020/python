
from .drivers.kafka_processor import KafkaProducer


class LoadProcessFactory:

    process_list = ['kafka']

    @classmethod
    def create_process_driver(cls, process, config):
        print()
        if process in cls.process_list:
            return KafkaProducer()
