
from kafka.admin import KafkaAdminClient, ACLPermissionType, ResourcePattern, ResourceType, ACL, ACLOperation, ACLFilter, NewTopic, ConfigResource, ConfigResourceType
from kafka import KafkaProducer, KafkaConsumer
from termcolor import colored, cprint
from time import sleep
from json import dumps
import fire
import yaml
import subprocess
from kafka.errors import TopicAlreadyExistsError
from confluent_kafka import Producer 


class ConnectBroker(object):
  conf = {}
  def __init__(self, conf):

    if not conf.get('broker').get('server'):
      raise Exception('Broker address is missing')
    else:
      self.conf['bootstrap_servers'] = conf.get('broker').get('server')

    if conf.get('broker').get('username'):
      self.conf['sasl_plain_username'] = conf.get('broker').get('username')

    if conf.get('broker').get('password'):
      self.conf['sasl_plain_password'] = conf.get('broker').get('password')

    if conf.get('broker').get('sasl_mechanism'):
      self.conf['sasl_mechanism'] = conf.get('broker').get('sasl_mechanism')
    
    if conf.get('broker').get('security_protocol'):
      self.conf['security_protocol'] = conf.get('broker').get('security_protocol')
    
    # if conf.get('broker').get('sasl_mechanism'):
    #   self.conf['sasl_mechanism'] = conf.get('broker').get('sasl_mechanism')
    
    if conf.get('broker').get('cert').get('ca'):
      self.conf['ssl_cafile'] = conf.get('broker').get('cert').get('ca')
    
    if conf.get('broker').get('cert').get('cert'):
      self.conf['ssl_certfile'] = conf.get('broker').get('cert').get('cert')

    if conf.get('broker').get('cert').get('key'):
      self.conf['ssl_keyfile'] = conf.get('broker').get('cert').get('key')

    if conf.get('broker').get('ssl_password'):
      self.conf['ssl_password'] = conf.get('broker').get('ssl_password')      
    
    
    # print(self.conf)
    # self.connection()
    # self.producer = self.producer_client()
    # self.consumer = self.consumer_client()


  def admin(self):
    # print(self.conf.get('bootstrap_servers'),self.conf.get('security_protocol'))
    # self.broker = KafkaAdminClient(
    #   **self.conf
    # )
    return  KafkaAdminClient(
      **self.conf
    )

  def producer(self, serializer, username, password):
    print( username, password)
    
    self.conf["sasl_plain_username"]=username
    self.conf["sasl_plain_password"]=password
    self.conf["value_serializer"]=serializer
    conf = {
        'bootstrap.servers': self.conf.get('bootstrap_servers'),
        'security.protocol': self.conf.get('security_protocol'),
        'sasl.mechanisms': self.conf.get('sasl_mechanism'),
        'ssl.ca.location': self.conf.get('ssl_cafile'),
        'sasl.username': username,
        'sasl.password': password, 
        # any other config you like ..
    }
    
    print(conf)

    return Producer(
      **conf,
    )

  def consumer(self):
    # print(self.conf)
    return KafkaProducer(
      **self.conf
    )


class Configuration(object):
  def __init__(self, yaml_file):
    self.config = self.read_file(yaml_file)

  def read_file(self, file):
    with open(file, "r") as stream:
      try:
          self.conf = yaml.safe_load(stream)
          # print(self.conf )
      except yaml.YAMLError as exc:
          print("Invalid configuration file")

    return



class Configs(object):
  def __init__(self,conf, broker):
    self.broker = broker
    self.conf = conf 

  def add(self, ):
    """
         # Create topic owner
                    topic_username = str(attributes.get('topic-username'))
                    topic_password = str(attributes.get('topic-password'))
                    #resource = ConfigResource('Users', topic_username)
                    resource = ConfigResource(ConfigResource.Type.ANY, topic_username)
                    describe_configs = admin.describe_configs([resource])
                    describe_configs['SCRAM-SHA-256'] = f'[iterations=8192,password={topic_password}]'
                    describe_configs['SCRAM-SHA-512'] = f'[password={topic_password}]'
                    admin.alter_configs([resource])
                    # Create ACL rule
                    acl = AclBinding(ResourceType.TOPIC, topic_name, 
                                     ResourcePatternType.MATCH, f'User:{topic_username}', None, 
                                     AclOperation.ALL, AclPermissionType.ALLOW)
                    admin.create_acls([acl])
    """
    # print(self.conf)
    for user in self.conf.get('activity').get('cname'):
    # command = "{command} --bootstrap-servers {bootstrap_servers} --alter --add-config {password} --entity-type users --entity-name {username}".format(bootstrap_servers=self.conf.get('broker').get('server'), password=self.conf.get(''))
      cmd = [self.conf.get('command'), "--zookeeper", self.conf.get('zookeeper'), "--alter" , "--add-config", '\''+user.get('pass')+'\'', "--entity-type", "users","--entity-name", user.get('user')]
      text = colored(user.get('user'), 'green', attrs=[])
      print()
      print()
      print("Creating users {user}".format(user=text))
      subprocess.run(" ".join(cmd), shell=True, check=True)

class Topic(object):
  """Creates topic listed in the configuration under activity.topics property
  arg : broker connection
        configuration object form yaml
  """
  def __init__(self, conf, broker):  
    self.broker = broker
    self.conf = conf

  def create(self):
    
      result = None
      topics = []
      for topic in self.conf.get('activity').get('topics'):
        try:
          text = colored(topic, 'green', attrs=[])
          
          c_topic = NewTopic(topic.get('name'), num_partitions=topic.get('partition'), replication_factor=topic.get('replication'))
          topics.append(c_topic)
          
          rtopics = self.broker.create_topics([c_topic])
          print("Creating topic {data}".format(data=text))
          topics.append(rtopics)
        except TopicAlreadyExistsError:
          text = colored(topic.get('name'), 'green', attrs=[])
          print("Topic {data} Already exist".format(data=text))
      return self



  def acl(self):
    acls = []
    for it in self.conf.get('activity').get('acls'):
      print(it)
      for user in it.get('users'):
        for role in user.get('perm'):
          acls.append( ACL(
            principal="User:{user}".format(user=user.get('cn')),
            host=it.get('host'),
            operation=self.operation(role.get('o')),
            permission_type=self.permission(role.get('p')),
            resource_pattern=ResourcePattern(ResourceType.TOPIC, NewTopic(it.get('topic'), num_partitions=3, replication_factor=1))
          ))
 
    # acls_result = self.broker.create_acls([acl1])
    # print(self.broker)
    acls_result = self.broker.create_acls(acls)
    print(acls_result)
    return self
  

  def list(self,):
    print(self.broker.list_topics())
    return self
  
  def test(self):
    connection = ConnectBroker(self.conf)
    producer = None

    for it in self.conf.get('activity').get('acls'):
      for user in it.get('users'):
        print(user)
        producer = connection.producer(lambda x: 
                          dumps(x).encode('utf-8'), user.get('cn'), user.get('pwd'))

        # print(it)
        for user in it.get('users'):
          for role in user.get('perm'):    
            for e in range(10):
              data = {'number' : e}
              print(data)
              producer.produce(it.get('topic'), value=dumps(data).encode('utf-8'))
              # producer.flush()
              sleep(1)

    
    


    return ''


  def permission(self, operand):
    if operand == 'a':
      return ACLPermissionType.ALLOW
    elif operand == 'd':
      return ACLPermissionType.DENY
    elif operand == 'b':
      return ACLPermissionType.ANY


  def operation(self, permission):

    if permission == 'r':
      return ACLOperation.READ
    elif permission == 'w':
      return ACLOperation.WRITE
    elif permission == 'a':
      return ACLOperation.ALL
    elif permission == 'd':
      return ACLOperation.DESCRIBE

  

class Test(object):

  def __init__(self, conf, broker):  
    self.broker = broker
    self.conf = conf

  def test(self, volume=1):
    
    return ' '.join(['Burp!'] * volume)


class Pipeline(object):

  def __init__(self, file):
    # print(config)
    self.configuration = Configuration(file)
    self.server_connection = ConnectBroker(self.configuration.conf)
    
    self.topic =  Topic(self.configuration.conf, self.server_connection.admin(),)
    self.configs = Configs(self.configuration.conf, self.server_connection.admin())
    # self.validate = Test(self.configuration.conf, self.server_connection.producer())
    
    # self.server_connection = ConnectBroker(bootstrap_brokers, password, username, ssl_password, security_protocol=security_protocol, sasl_mechanism=sasl_mechanism,cert_file=cert_file, cert_key=cert_key, ca_file=ca_file )
    # self.server_connection.connection()
     # python acl-creator.py run --bootstrap_brokers=pop-os.localdomain:19093 --username=admin --password=hAHsm12ls0X --cert-file=/home/performvu/workspace/docker-compose/kafka-cluster/kcerts/ca-cert.pem --cert-key=/home/performvu/workspace/docker-compose/kafka-cluster/kcerts/truststore/ca-key --security-protocol='SASL_SSL' --sasl-mechanism='SCRAM-SHA-512' --ssl-password='hello.world' --ca-file /home/performvu/workspace/docker-compose/kafka-cluster/kcerts/ca-cert

    

if __name__ == '__main__':
  fire.Fire(Pipeline)
